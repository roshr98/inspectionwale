# Master version for Pillow
from __future__ import annotations

__version__ = "10.4.0"
